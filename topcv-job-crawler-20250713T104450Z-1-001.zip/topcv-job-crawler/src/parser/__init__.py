"""TopCV Parser module for extracting job information from TopCV.vn"""

from src.parser.main import TopCVParser

__all__ = ['TopCVParser'] 